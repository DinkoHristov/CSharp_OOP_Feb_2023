﻿using Formula1.Models;
using Formula1.Models.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Formula1.Repositories.Contracts
{
    public interface IFormulaOneCarRepository : IRepository<IFormulaOneCar>
    {

    }
}
