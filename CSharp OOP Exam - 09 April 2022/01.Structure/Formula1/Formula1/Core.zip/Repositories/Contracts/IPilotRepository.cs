﻿using Formula1.Models.Contracts;
using Formula1.Utilities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Formula1.Repositories.Contracts
{
    public interface IPilotRepository : IRepository<IPilot>
    {

    }
}
