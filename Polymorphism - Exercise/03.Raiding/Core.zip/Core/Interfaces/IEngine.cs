﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.Raiding.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}
