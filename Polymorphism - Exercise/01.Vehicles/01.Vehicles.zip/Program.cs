﻿using System;

namespace _01.Vehicles
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string[] carInfo = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            Vehicle car = 
                new Car(double.Parse(carInfo[1]), double.Parse(carInfo[2]));

            string[] truckInfo = Console.ReadLine()
               .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            Vehicle truck = 
                new Truck(double.Parse(truckInfo[1]), double.Parse(truckInfo[2]));

            int count = int.Parse(Console.ReadLine());
            for (int i = 0; i < count; i++)
            {
                string[] input = Console.ReadLine()
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries);
                string commandType = input[0];

                if (commandType == "Drive")
                {
                    string vehicleType = input[1];
                    double kilometers = double.Parse(input[2]);

                    if (vehicleType == "Car")
                    {
                        Console.WriteLine(car.Drive(kilometers));
                    }
                    else if (vehicleType == "Truck")
                    {
                        Console.WriteLine(truck.Drive(kilometers));
                    }
                }
                else if (commandType == "Refuel")
                {
                    string vehicleType = input[1];
                    double litersToRefuel = double.Parse(input[2]);

                    if (vehicleType == "Car")
                    {
                        car.Refuel(litersToRefuel);
                    }
                    else if (vehicleType == "Truck")
                    {
                        truck.Refuel(litersToRefuel);
                    }
                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity:F2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:F2}");
        }
    }
}
