﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.MilitaryElite.Enums
{
    public enum State
    {
        inProgress,
        Finished
    }
}
