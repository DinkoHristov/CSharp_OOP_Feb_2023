﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _07.MilitaryElite.Core.Interface
{
    public interface IEngine
    {
        void Run();
    }
}
