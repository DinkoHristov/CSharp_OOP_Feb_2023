﻿namespace WarCroft.Entities.Characters.Contracts
{
	public interface IHealer
	{
		void Heal(Character character);
	}
}